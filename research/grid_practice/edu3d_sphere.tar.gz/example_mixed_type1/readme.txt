#

# Compile the code

gfortran -O2 ../sphere_grid_v06.f90

# Run

./a.out



